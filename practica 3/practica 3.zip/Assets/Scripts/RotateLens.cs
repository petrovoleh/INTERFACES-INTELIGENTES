using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateLens : MonoBehaviour
{
    void Update()
    {
        transform.forward = Vector3.forward;
    }
}
